'use strict';

// go back to page 1 when clicked on restart button
function restart(){
    window.location.href = "page1.html";
}