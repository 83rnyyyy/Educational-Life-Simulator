import * as THREE from "https://cdn.skypack.dev/three@0.129.0";
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';